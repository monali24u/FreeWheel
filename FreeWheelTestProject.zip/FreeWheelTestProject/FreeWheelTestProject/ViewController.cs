﻿using System;
using System.Text;
using System.Collections.Generic;
using AppKit;
using Foundation;
using System.Linq;
using System.Globalization;

namespace FreeWheelTestProject {
	public partial class ViewController : NSViewController {

		// Corresponds to PROGRAM.sql
		public class Program
		{
			//PROGRAM_ID INT IDENTITY (1,1),
			//STATION_ID INT,
			//PROGRAM_NAME VARCHAR (50),
			//FLIGHT_DATE DATETIME,

			public int _program_Id;
			public int _station_Id;
			public string _program_Name;
			public DateTime _flight_Date;

			public Program(int pId, int sId, string pName, DateTime flDate)
			{
				_program_Id = pId;
				_station_Id = sId;
				_program_Name = pName;
				_flight_Date = flDate;
			}
		}

		// Corresponds to STATION.sql
		public class Station {

			//STATION_ID INT IDENTITY (1,1),
			//STATION_NAME VARCHAR (50),

			public int _station_Id;
			public string _station_Name;

			public Station(int sId, string sName)
			{
				_station_Id = sId;
				_station_Name = sName;
			}
		}

		// Corresponds to MARKET.sql
		public class Market {

			//	MARKET_ID INT IDENTITY (1,1),
			//	MARKET_NAME VARCHAR (50),

			public int _market_Id;
			public string _market_Name;

			public Market(int mId, string mName)
			{
				_market_Id = mId;
				_market_Name = mName;
			}
		}

		// Corresponds to CELLS.sql
		public class Cells {

			//CELL_ID INT IDENTITY (1,1),
			//CELL VARCHAR (50),

			public int _cell_Id;
			public string _cell;

			public Cells(int cId, string cName)
			{
				_cell_Id = cId;
				_cell = cName;
			}
		}

		// Corresponds to MARKET_POP.sql
		public class Market_Pop {

			//MARKET_ID INT,
			//CELL_ID INT,

			public int _market_Id;
			public int _cell_Id;

			public Market_Pop(int mId, int cId)
			{
				_market_Id = mId;
				_cell_Id = cId;
			}
		}

		List<Program> programs = new List<Program>();
		List<Station> stations = new List<Station>();
		List<Market> markets = new List<Market>();
		List<Cells> getCells = new List<Cells>();
		List<Market_Pop> marketPops = new List<Market_Pop>();

		public ViewController (IntPtr handle) : base (handle)
		{
			// Create a mock database

			// programs
			CultureInfo culture = CultureInfo.CreateSpecificCulture ("en-US");

			programs.Add (new Program (1, 1, "10 O''CLOCK NWS", DateTime.Parse("3/11/1990", culture)));
			programs.Add (new Program (2, 1, "ACCESS HOLLYWD", DateTime.Parse ("8/25/1991", culture)));
			programs.Add (new Program (3, 4, "Jeop", DateTime.Parse ("6/30/1975", culture)));
			programs.Add (new Program (4, 3, "TC O''BRIEN-NBC''''Program", DateTime.Parse ("1/1/1989", culture)));
			programs.Add (new Program (5, 3, "Frasier''s", DateTime.Parse ("11/11/1991", culture)));
			programs.Add (new Program (6, 4, "Barney", DateTime.Parse ("9/3/1966", culture)));
			programs.Add (new Program (7, 1, "Just Shoot me", DateTime.Parse ("6/6/1996", culture)));
			programs.Add (new Program (8, 4, "Wheel", DateTime.Parse ("6/30/1975", culture)));
			programs.Add (new Program (9, 3, "Sesame Street", DateTime.Parse ("5/16/1971", culture)));
			programs.Add (new Program (10, 1, "Abcd ws", DateTime.Parse ("3/11/1990", culture)));


			// Markets
			markets.Add (new Market (1, "Chicago"));
			markets.Add (new Market (2, "New York"));
			markets.Add (new Market (3, "Los Angeles"));
			markets.Add (new Market (4, "Atlanta"));
			markets.Add (new Market (5, "Roanoke-Lynchburg"));
			markets.Add (new Market (6, "Yourtown"));

			// Cells
			getCells.Add (new Cells (1, "Men 12-17"));
			getCells.Add (new Cells (2, "Men 18-24"));
			getCells.Add (new Cells (3, "Men 25-34"));
			getCells.Add (new Cells (4, "Men 35-49"));
			getCells.Add (new Cells (5, "Men 50-54"));
			getCells.Add (new Cells (6, "Women 12-17"));
			getCells.Add (new Cells (7, "Women 18-24"));
			getCells.Add (new Cells (8, "Women 25-34"));
			getCells.Add (new Cells (9, "Women 35-49"));
			getCells.Add (new Cells (10, "Women 50-54"));

			// Market_Pop
			marketPops.Add (new Market_Pop (1, 1));
			marketPops.Add (new Market_Pop (1, 2));
			marketPops.Add (new Market_Pop (2, 4));

			// stations
			stations.Add (new Station (1, "WABC-TV"));
			stations.Add (new Station (2, "WHIJ-TV"));
			stations.Add (new Station (3, "AAAA-TV"));
			stations.Add (new Station (4, "KKKK-TV"));
		}

		public override void ViewDidLoad ()
		{
			base.ViewDidLoad ();

			// Do any additional setup after loading the view.
			// Setup the combo box with stations
			stationComboBox.RemoveAll ();
			foreach(var st in stations) {
				stationComboBox.Add (new NSString (st._station_Name));
			}
		}

		public override NSObject RepresentedObject {
			get {
				return base.RepresentedObject;
			}
			set {
				base.RepresentedObject = value;
				// Update the view, if already loaded.
			}
		}
		
		private string ProcessProgramName(List<Program> programs)
		{
			var pnames = new List<string>();
			var result = new List<string>();

			// Get program names first
			foreach (var pr in programs) {

				pnames.Add(pr._program_Name);
			}

			// This is to just show input data in the UI
			inputLabel.StringValue = string.Join (" , ", pnames);

			// Sort program names
			pnames.Sort();

			// Add apostrophe as per requirements
			foreach (var p in pnames) {

				var sb = new StringBuilder ();
				sb.Append ("'");

				foreach(var letter in p) {
					if (letter == '\'') {
						sb.Append ("''");
					} else
						sb.Append (letter);

				}

				sb.Append ("'");
				result.Add (sb.ToString ());
			}

			// Convert result to string
			var finalResult = string.Join (" , ", result);
			return finalResult;
		}

		private string PopulateMissingRecordsOfMarketPop(List<Market> markets, List<Cells> cells, List<Market_Pop> mPops)
		{
			var result = new List<string> ();
			var myset = new HashSet<(int mId, int cId)> ();

			// Get all combination of cell and market
			foreach(var mk in markets) {

				foreach(var c in cells) {
					myset.Add ((mk._market_Id, c._cell_Id));
				}
			}
			var input = new List<string> ();

			// Remove existing combination of cell and market
			foreach (var mkPop in mPops) {

				if(myset.Contains((mkPop._market_Id, mkPop._cell_Id))) {
					myset.Remove ((mkPop._market_Id, mkPop._cell_Id));
				}

				var str = "" + mkPop._market_Id + "_" + mkPop._cell_Id;
				input.Add (str);
			}

			// This is to just show input data in the UI
			inputLabel.StringValue = string.Join (" , ", input);

			foreach (var entry in myset) {
				var str = "" + entry.mId + "_" + entry.cId;
				result.Add (str);
			}

			// Convert result to string
			var finalResult = string.Join (" , ", result);
			return finalResult;
		}

		partial void ProcessProgramNameBtn (NSObject sender)
		{
			label1.StringValue = ProcessProgramName (programs);
		}

		partial void ShowMissingRecordsBtn (NSObject sender)
		{
			label2.StringValue = PopulateMissingRecordsOfMarketPop (markets, getCells, marketPops);
		}

		// Button to action on the selected station
		partial void updateBtn (NSObject sender)
		{
			if (stationComboBox.SelectedIndex == -1) { 
				inputLabel.StringValue = "";
				label3.StringValue = "";
				return;
			}
				

			nint val = stationComboBox.SelectedIndex;
			var programList = new List<Program> ();

			var input = new List<string> ();

			// Populate progrm data for selected station
			foreach (var p in programs) {
				if (p._station_Id == val + 1) {
					programList.Add (p);
					string temp = p._program_Id + " , " + p._station_Id + " , " + p._program_Name + " , " + p._flight_Date.ToString ("dd/M/yyyy");
					input.Add (temp);
				}

			}

			// This is to just show input data in the UI
			inputLabel.StringValue = string.Join (" , ", input);

			// Sort as per the date
			var result = programList.OrderBy (a => a._flight_Date).ThenBy (b => b._program_Name).Take (1).ToList ();

			var finalResult = "";
			if (result.Count > 0) {
				finalResult = result [0]._program_Id + " , " + result [0]._station_Id + " , " + result [0]._program_Name + " , " + result [0]._flight_Date.ToString("MMMM d, yyyy");				
			}
			else {
				finalResult = "No Records Available";
			}

			label3.StringValue = finalResult;
		}
	}
	
}
