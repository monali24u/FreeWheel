// WARNING
//
// This file has been generated automatically by Visual Studio to store outlets and
// actions made in the UI designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using Foundation;
using System.CodeDom.Compiler;

namespace FreeWheelTestProject
{
	[Register ("ViewController")]
	partial class ViewController
	{
		[Outlet]
		AppKit.NSTextField inputLabel { get; set; }

		[Outlet]
		AppKit.NSTextField label1 { get; set; }

		[Outlet]
		AppKit.NSTextField label2 { get; set; }

		[Outlet]
		AppKit.NSTextField label3 { get; set; }

		[Outlet]
		AppKit.NSComboBox stationComboBox { get; set; }

		[Action ("ProcessProgramNameBtn:")]
		partial void ProcessProgramNameBtn (Foundation.NSObject sender);

		[Action ("ShowMissingRecordsBtn:")]
		partial void ShowMissingRecordsBtn (Foundation.NSObject sender);

		[Action ("updateBtn:")]
		partial void updateBtn (Foundation.NSObject sender);
		
		void ReleaseDesignerOutlets ()
		{
			if (inputLabel != null) {
				inputLabel.Dispose ();
				inputLabel = null;
			}

			if (label1 != null) {
				label1.Dispose ();
				label1 = null;
			}

			if (label2 != null) {
				label2.Dispose ();
				label2 = null;
			}

			if (label3 != null) {
				label3.Dispose ();
				label3 = null;
			}

			if (stationComboBox != null) {
				stationComboBox.Dispose ();
				stationComboBox = null;
			}
		}
	}
}
